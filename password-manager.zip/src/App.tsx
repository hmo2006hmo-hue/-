import { useState, useEffect, useMemo, useCallback, FormEvent } from "react";
import { 
  ShieldCheck, 
  ShieldAlert, 
  Trash2, 
  Plus, 
  Search, 
  Lock, 
  Unlock, 
  ExternalLink, 
  Copy, 
  Check, 
  Eye, 
  EyeOff, 
  Save, 
  X, 
  KeyRound, 
  BrainCircuit, 
  Sparkles, 
  AlertCircle, 
  Filter, 
  Clock, 
  User, 
  Tag, 
  LogOut, 
  Info,
  ChevronDown,
  Smartphone,
  CheckCircle2,
  Cpu,
  Send,
  AlertTriangle,
  FileText,
  Mail,
  RefreshCw,
  EyeIcon,
  HelpCircle,
  Hash
} from "lucide-react";
import { VaultItem, ChatMessage, CategoryType, VaultStats } from "./types";
import { encryptText, decryptText, analyzePassword } from "./utils/crypto";
import MasterPasswordScreen from "./components/MasterPasswordScreen";
import PasswordGenerator from "./components/PasswordGenerator";
import { motion, AnimatePresence } from "motion/react";

// Fallback UUID generator to guarantee browser consistency in sandbox iframes
const generateUUID = () => {
  return `${Math.random().toString(36).substring(2, 11)}-${Date.now().toString(36)}`;
};

const CATEGORY_LABELS: Record<string, string> = {
  all: "All Accounts",
  social: "Social Media",
  personal: "Personal",
  work: "Professional Work",
  financial: "Financial & Cards",
  shopping: "Online Shopping",
  other: "Others"
};

const CATEGORY_COLORS: Record<string, string> = {
  social: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  personal: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  work: "bg-amber-500/10 text-amber-400 border-amber-500/20",
  financial: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
  shopping: "bg-pink-500/10 text-pink-400 border-pink-500/20",
  other: "bg-slate-500/10 text-slate-300 border-slate-500/20"
};

// Advanced platform-matching data model for simulated branding & automated logo allocation
interface PlatformSpec {
  name: string;
  brandColor: string;
  bgColor: string;
  borderColor: string;
  category: "social" | "personal" | "work" | "financial" | "shopping" | "other";
}

const PLATFORM_SIGNATURES: Record<string, PlatformSpec> = {
  telegram: { name: "Telegram Messenger", brandColor: "#229ED9", bgColor: "bg-[#229ED9]/10", borderColor: "border-[#229ED9]/20", category: "social" },
  facebook: { name: "Facebook Connect", brandColor: "#1877F2", bgColor: "bg-[#1877F2]/10", borderColor: "border-[#1877F2]/20", category: "social" },
  instagram: { name: "Instagram Social", brandColor: "#E1306C", bgColor: "bg-[#E1306C]/10", borderColor: "border-[#E1306C]/20", category: "social" },
  google: { name: "Google Accounts", brandColor: "#EA4335", bgColor: "bg-[#EA4335]/10", borderColor: "border-[#EA4335]/20", category: "personal" },
  gmail: { name: "Google Accounts", brandColor: "#EA4335", bgColor: "bg-[#EA4335]/10", borderColor: "border-[#EA4335]/20", category: "personal" },
  github: { name: "GitHub Codespaces", brandColor: "#10b981", bgColor: "bg-slate-800", borderColor: "border-slate-700", category: "work" },
  linkedin: { name: "LinkedIn Career", brandColor: "#0077B5", bgColor: "bg-[#0077B5]/10", borderColor: "border-[#0077B5]/20", category: "work" },
  twitter: { name: "Twitter / X Social", brandColor: "#1da1f2", bgColor: "bg-slate-950", borderColor: "border-slate-800", category: "social" },
  x: { name: "Twitter / X Social", brandColor: "#ffffff", bgColor: "bg-slate-950", borderColor: "border-slate-800", category: "social" },
  paypal: { name: "PayPal Financial", brandColor: "#003087", bgColor: "bg-[#003087]/10", borderColor: "border-[#003087]/20", category: "financial" },
  stripe: { name: "Stripe Merchant", brandColor: "#635BFF", bgColor: "bg-[#635BFF]/10", borderColor: "border-[#635BFF]/20", category: "financial" },
  netflix: { name: "Netflix Video", brandColor: "#E50914", bgColor: "bg-[#E50914]/10", borderColor: "border-[#E50914]/20", category: "shopping" },
  amazon: { name: "Amazon Shopping", brandColor: "#FF9900", bgColor: "bg-[#FF9900]/10", borderColor: "border-[#FF9900]/20", category: "shopping" },
  spotify: { name: "Spotify Music", brandColor: "#1ED760", bgColor: "bg-[#1ED760]/10", borderColor: "border-[#1ED760]/20", category: "personal" },
  slack: { name: "Slack Collective", brandColor: "#4A154B", bgColor: "bg-[#4A154B]/10", borderColor: "border-[#4A154B]/20", category: "work" }
};

export default function App() {
  const [masterPassword, setMasterPassword] = useState<string | null>(null);
  const [items, setItems] = useState<VaultItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<VaultItem | null>(null);
  
  // Tab within simulated mobile container
  const [activeMobileTab, setActiveMobileTab] = useState<"vault" | "generator" | "guard" | "settings">("vault");

  // Filter & Search
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<CategoryType>("all");

  // Decryption caches
  const [decryptedPasswords, setDecryptedPasswords] = useState<Record<string, string>>({});
  const [revealTimer, setRevealTimer] = useState<Record<string, number>>({});
  const [copyStatus, setCopyStatus] = useState<Record<string, boolean>>({});

  // Form states (Add/Edit)
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [formError, setFormError] = useState("");
  
  const [formTitle, setFormTitle] = useState("");
  const [formEmailOrUsername, setFormEmailOrUsername] = useState("");
  const [formWebsite, setFormWebsite] = useState("");
  const [formPassword, setFormPassword] = useState("");
  const [formCategory, setFormCategory] = useState<"social" | "personal" | "work" | "financial" | "shopping" | "other">("social");
  const [formNotes, setFormNotes] = useState("");
  const [formTags, setFormTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState("");
  const [formPasswordStrength, setFormPasswordStrength] = useState({ score: 0, strength: "weak" as "weak" | "moderate" | "strong", timeToCrack: "Instant" });

  // System Accessibility & Autofill Framework simulation switches
  const [accessibilityActive, setAccessibilityActive] = useState(true);
  const [autofillServiceActive, setAutofillServiceActive] = useState(true);
  const [selectedMockTarget, setSelectedMockTarget] = useState<"instagram" | "telegram" | "google" | "paypal">("instagram");
  const [mockEmailInput, setMockEmailInput] = useState("");
  const [mockPasswordInput, setMockPasswordInput] = useState("");
  const [mockTargetAnimation, setMockTargetAnimation] = useState(false);
  const [clipboardLeakedWarning, setClipboardLeakedWarning] = useState<string | null>(null);
  const [autofillToast, setAutofillToast] = useState<string | null>(null);

  // Gemini expert secure chat
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const [chatError, setChatError] = useState("");

  // Simulated Web-to-Native Bridge API code view choice
  const [selectedCodeSpec, setSelectedCodeSpec] = useState<"android" | "ios" | "accessibility">("android");

  // Parse platform name for automated matching branding
  const getMatchedPlatformSpec = useCallback((title: string): PlatformSpec | null => {
    if (!title) return null;
    const lower = title.toLowerCase().trim();
    for (const key of Object.keys(PLATFORM_SIGNATURES)) {
      if (lower.includes(key)) {
        return PLATFORM_SIGNATURES[key];
      }
    }
    return null;
  }, []);

  // Sync vault setup
  useEffect(() => {
    if (masterPassword) {
      const stored = localStorage.getItem("slate_vault_items");
      if (stored) {
        try {
          setItems(JSON.parse(stored));
        } catch (e) {
          console.error("Local secure storage parse failure", e);
        }
      } else {
        // Hydrate demo safe seeds with timestamps to demonstrate features out of the box
        const demoSeed: VaultItem[] = [
          {
            id: "fake-id-1",
            title: "Instagram Enterprise",
            emailOrUsername: "marketing@brand.corp",
            encryptedPassword: "W:demo-encrypted-pass-1", 
            category: "social",
            notes: "Main marketing and broadcast hub.",
            tags: ["social", "meta"],
            createdAt: "2026-05-24T08:12:00.000Z",
            lastModifiedAt: "2026-05-24T10:15:30.000Z",
            strength: "strong",
            score: 85,
            website: "https://instagram.com"
          },
          {
            id: "fake-id-2",
            title: "Google Core Connect",
            emailOrUsername: "hmo2006hmo@gmail.com",
            encryptedPassword: "W:demo-encrypted-pass-2",
            category: "personal",
            notes: "Personal Google recovery and Maps suite.",
            tags: ["google", "recovery"],
            createdAt: "2026-05-23T14:24:10.000Z",
            lastModifiedAt: "2026-05-23T14:24:10.000Z",
            strength: "strong",
            score: 95,
            website: "https://google.com"
          },
          {
            id: "fake-id-3",
            title: "Corporate Telegram Admin",
            emailOrUsername: "+1 (555) 392-1049",
            encryptedPassword: "W:demo-encrypted-pass-3",
            category: "social",
            notes: "Access channel keys for operational deployments.",
            tags: ["telegram", "operation"],
            createdAt: "2026-05-20T09:05:12.000Z",
            lastModifiedAt: "2026-05-22T19:40:00.000Z",
            strength: "moderate",
            score: 65,
            website: "https://telegram.org"
          }
        ];
        
        // Save seed securely with simulated encrypt placeholder text
        const secureDemoPromise = async () => {
          const hydrated = await Promise.all(demoSeed.map(async item => {
            const rawPw = item.id === "fake-id-1" ? "MetaEmerald#2026!" : item.id === "fake-id-2" ? "G00gl3*C0r3!S3cur3" : "TelAdminKey9";
            const encrypted = await encryptText(rawPw, masterPassword);
            return {
              ...item,
              encryptedPassword: encrypted
            };
          }));
          setItems(hydrated);
          localStorage.setItem("slate_vault_items", JSON.stringify(hydrated));
        };
        secureDemoPromise();
      }

      setChatMessages([
        {
          id: "welcome-cyber-guard",
          role: "assistant",
          content: "Welcome to the Slate Smart Cyber Adviser. I can analyze password resilience, propose strong key layouts, explain iOS Auto-Fill API structures, or audit vulnerability risks. Ready to protect your identity.",
          timestamp: new Date().toLocaleTimeString("en-US", { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  }, [masterPassword]);

  const handleLock = useCallback(() => {
    setMasterPassword(null);
    setItems([]);
    setSelectedItem(null);
    setDecryptedPasswords({});
    setCopyStatus({});
    setMockEmailInput("");
    setMockPasswordInput("");
  }, []);

  const syncItemsToStorage = (newItems: VaultItem[]) => {
    setItems(newItems);
    localStorage.setItem("slate_vault_items", JSON.stringify(newItems));
  };

  // Compute local vulnerability stats
  const calculateStats = useMemo<VaultStats>(() => {
    const stats: VaultStats = {
      total: items.length,
      weakCount: 0,
      moderateCount: 0,
      strongCount: 0,
      reusedCount: 0
    };

    const seenPasswords = new Set<string>();
    const reusedPasswords = new Set<string>();

    items.forEach(item => {
      if (item.strength === "strong") stats.strongCount++;
      else if (item.strength === "moderate") stats.moderateCount++;
      else stats.weakCount++;

      if (seenPasswords.has(item.encryptedPassword)) {
        reusedPasswords.add(item.encryptedPassword);
      } else {
        seenPasswords.add(item.encryptedPassword);
      }
    });

    items.forEach(item => {
      if (reusedPasswords.has(item.encryptedPassword)) {
        stats.reusedCount++;
      }
    });

    return stats;
  }, [items]);

  // Filter Vault list
  const filteredItems = useMemo(() => {
    return items.filter(item => {
      const q = searchQuery.toLowerCase();
      const matchesSearch = 
        item.title.toLowerCase().includes(q) ||
        item.emailOrUsername.toLowerCase().includes(q) ||
        (item.website && item.website.toLowerCase().includes(q)) ||
        item.notes.toLowerCase().includes(q) ||
        item.tags.some(t => t.toLowerCase().includes(q));

      const matchesCategory = selectedCategory === "all" || item.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [items, searchQuery, selectedCategory]);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopyStatus(prev => ({ ...prev, [id]: true }));
    
    // Safety warning of simulated clipboard clearing
    setClipboardLeakedWarning(`Copied to clipboard. Local host background service will clear clipboard in 15s to defend against spyware.`);

    setTimeout(() => {
      setCopyStatus(prev => ({ ...prev, [id]: false }));
    }, 2000);

    // Simulated local safe clear
    setTimeout(() => {
      navigator.clipboard.writeText("");
      setClipboardLeakedWarning("Clipboard cleared defensively.");
      setTimeout(() => setClipboardLeakedWarning(null), 3000);
    }, 15000);
  };

  const handleDecrypt = async (encrypted: string, id: string) => {
    if (decryptedPasswords[id]) {
      setDecryptedPasswords(prev => {
        const next = { ...prev };
        delete next[id];
        return next;
      });
      return;
    }

    if (!masterPassword) return;

    try {
      const decrypted = await decryptText(encrypted, masterPassword);
      setDecryptedPasswords(prev => ({ ...prev, [id]: decrypted }));

      if (revealTimer[id]) {
        clearTimeout(revealTimer[id]);
      }

      // Hide after a strict 15 seconds physical safety timer
      const timer = window.setTimeout(() => {
        setDecryptedPasswords(prev => {
          const next = { ...prev };
          delete next[id];
          return next;
        });
      }, 15000);

      setRevealTimer(prev => ({ ...prev, [id]: timer }));
    } catch (e: any) {
      alert("Decryption key error: " + (e.message || "Invalid cipher key."));
    }
  };

  const handleFormPasswordChange = (val: string) => {
    setFormPassword(val);
    if (val) {
      setFormPasswordStrength(analyzePassword(val));
    } else {
      setFormPasswordStrength({ score: 0, strength: "weak", timeToCrack: "Instant" });
    }
  };

  // Auto-fill trigger simulation
  const handleAutofillAction = async (targetItem: VaultItem) => {
    if (!autofillServiceActive) {
      setAutofillToast("❌ System Autofill Engine disabled. Toggle it 'ON' in Settings / Developer Sidebar.");
      setTimeout(() => setAutofillToast(null), 4000);
      return;
    }

    if (!masterPassword) return;

    setMockTargetAnimation(true);
    try {
      // Fetch credential
      const decrypted = await decryptText(targetItem.encryptedPassword, masterPassword);
      
      // Simulate native IPC transmit timing
      setTimeout(() => {
        setMockEmailInput(targetItem.emailOrUsername);
        setMockPasswordInput(decrypted);
        setMockTargetAnimation(false);
        setAutofillToast(`⚡ Secure Accessibility Service Filled "${targetItem.title}" Credentials Successfully!`);
        setTimeout(() => setAutofillToast(null), 4000);
      }, 700);
    } catch (e) {
      setMockTargetAnimation(false);
      setAutofillToast("❌ Decryption key error during auto-fill handshake.");
    }
  };

  const handleAddTag = () => {
    const trimmed = tagInput.trim().toLowerCase();
    if (trimmed && !formTags.includes(trimmed)) {
      setFormTags([...formTags, trimmed]);
      setTagInput("");
    }
  };

  const handleRemoveTag = (tag: string) => {
    setFormTags(formTags.filter(t => t !== tag));
  };

  const openAddModal = () => {
    setFormTitle("");
    setFormEmailOrUsername("");
    setFormWebsite("");
    setFormPassword("");
    setFormCategory("social");
    setFormNotes("");
    setFormTags([]);
    setTagInput("");
    setFormPasswordStrength({ score: 0, strength: "weak", timeToCrack: "Instant" });
    setFormError("");
    setIsAdding(true);
    setIsEditing(false);
  };

  const openEditModal = async (item: VaultItem) => {
    if (!masterPassword) return;
    try {
      const plain = await decryptText(item.encryptedPassword, masterPassword);
      setFormTitle(item.title);
      setFormEmailOrUsername(item.emailOrUsername);
      setFormWebsite(item.website || "");
      setFormPassword(plain);
      setFormCategory(item.category);
      setFormNotes(item.notes);
      setFormTags(item.tags);
      setTagInput("");
      setFormPasswordStrength(analyzePassword(plain));
      setFormError("");
      setIsEditing(true);
      setIsAdding(false);
    } catch (e) {
      alert("Failed to decrypt for edit mode.");
    }
  };

  const handleSaveItem = async (e: FormEvent) => {
    e.preventDefault();
    setFormError("");

    if (!formTitle || !formPassword) {
      setFormError("Account name and Password are required fields.");
      return;
    }

    if (!masterPassword) return;

    try {
      const encrypted = await encryptText(formPassword, masterPassword);
      const metrics = analyzePassword(formPassword);
      const currentTimeString = new Date().toISOString();

      // Automated categorization based on popular social brand match if category is default 'other/social'
      let finalCategory = formCategory;
      const matchedSpec = getMatchedPlatformSpec(formTitle);
      if (matchedSpec) {
        finalCategory = matchedSpec.category;
      }

      if (isAdding) {
        const newItem: VaultItem = {
          id: generateUUID(),
          title: formTitle,
          emailOrUsername: formEmailOrUsername || "No login name",
          website: formWebsite,
          encryptedPassword: encrypted,
          category: finalCategory,
          notes: formNotes,
          tags: formTags,
          createdAt: currentTimeString,
          lastModifiedAt: currentTimeString,
          strength: metrics.strength,
          score: metrics.score
        };

        const updated = [newItem, ...items];
        syncItemsToStorage(updated);
        setSelectedItem(newItem);
        setIsAdding(false);
      } else if (isEditing && selectedItem) {
        const updated = items.map(item => {
          if (item.id === selectedItem.id) {
            const upd: VaultItem = {
              ...item,
              title: formTitle,
              emailOrUsername: formEmailOrUsername || "No login name",
              website: formWebsite,
              encryptedPassword: encrypted,
              category: finalCategory,
              notes: formNotes,
              tags: formTags,
              lastModifiedAt: currentTimeString, // update modified stamp
              strength: metrics.strength,
              score: metrics.score
            };
            setSelectedItem(upd);
            return upd;
          }
          return item;
        });
        syncItemsToStorage(updated);
        setIsEditing(false);
      }
    } catch (err) {
      setFormError("Cryptographic engine failed to seal the credential payload.");
    }
  };

  const handleDeleteItem = (id: string) => {
    if (confirm("🚨 Destroy record? This will permanently wipe this item from your offline database. Any recovery is impossible.")) {
      const updated = items.filter(item => item.id !== id);
      syncItemsToStorage(updated);
      setSelectedItem(null);
      setDecryptedPasswords(prev => {
        const next = { ...prev };
        delete next[id];
        return next;
      });
    }
  };

  // Gemini expert secure chat trigger
  const handleSendChatMessage = async (e: FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || chatLoading) return;

    const userMsg: ChatMessage = {
      id: generateUUID(),
      role: "user",
      content: chatInput,
      timestamp: new Date().toLocaleTimeString("en-US", { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages(prev => [...prev, userMsg]);
    const currentInput = chatInput;
    setChatInput("");
    setChatLoading(true);
    setChatError("");

    try {
      const response = await fetch("/api/security-assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: currentInput,
          chatHistory: chatMessages.slice(-5)
        })
      });

      const data = await response.json();
      if (response.ok) {
        setChatMessages(prev => [...prev, {
          id: generateUUID(),
          role: "assistant",
          content: data.reply,
          timestamp: new Date().toLocaleTimeString("en-US", { hour: '2-digit', minute: '2-digit' })
        }]);
      } else {
        setChatError(data.error || "Remote security assistant route failed.");
      }
    } catch (e) {
      setChatError("Verify API network status. Secure assistant fallback triggered.");
    } finally {
      setChatLoading(false);
    }
  };

  const handleUseGeneratedPasswordInForm = (pw: string) => {
    handleFormPasswordChange(pw);
    setActiveMobileTab("vault");
    setIsAdding(true);
  };

  // Render Lock Screen if locked
  if (!masterPassword) {
    return <MasterPasswordScreen onUnlock={setMasterPassword} />;
  }

  // Brand specs lookup for selected detail item
  const selectedBrandSpec = selectedItem ? getMatchedPlatformSpec(selectedItem.title) : null;

  return (
    <div id="password-manager-viewport" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans relative antialiased leading-normal">
      {/* Decorative emerald cyber matrix grids */}
      <div className="absolute top-0 right-0 w-full h-[600px] bg-gradient-to-bx from-emerald-500/5 via-transparent to-transparent pointer-events-none z-0" />
      <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:24px_24px] opacity-[0.03] pointer-events-none" />

      {/* Primary Desktop Top Navigation Frame */}
      <header className="border-b border-slate-900 bg-slate-900/60 backdrop-blur-md px-6 py-4 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/25 rounded-2xl">
              <ShieldCheck className="w-6 h-6 text-emerald-400" />
            </div>
            <div className="text-left">
              <h1 className="text-md font-bold text-white tracking-tight flex items-center gap-2">
                Slate Emerald Mobile Simulator
                <span className="text-[10px] uppercase py-0.5 px-2 rounded-full bg-emerald-500/10 font-bold border border-emerald-500/20 text-emerald-400">Offline AES-256</span>
              </h1>
              <span className="text-xs text-slate-400">Dual-sandbox suite showcasing secure Accessibility &amp; Auto-Fill capabilities</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-[10px] font-mono text-slate-500 bg-slate-950/80 px-2.5 py-1 rounded border border-slate-900">
              UTC: 2026-05-24 12:28:15
            </span>
            <button
              onClick={handleLock}
              className="flex items-center gap-1.5 px-4 py-1.5 bg-red-950/35 border border-red-900/30 hover:bg-red-900/30 text-red-400 hover:text-red-300 rounded-xl text-xs font-semibold select-none transition-colors cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5" />
              Lock Vault
            </button>
          </div>
        </div>
      </header>

      {/* Main Responsive Sandbox Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 md:px-6 py-8 relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* LEFT COLUMN: Deep System Accessibility & Autofill Framework Simulator Sandbox (5 columns on desktop) */}
        <section className="lg:col-span-5 space-y-6 text-left">
          <div className="bg-slate-900/50 border border-slate-900 rounded-3xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-emerald-400" />
                <h2 className="text-xs font-black uppercase tracking-wider text-slate-300">Accessibility Daemon &amp; Auto-Fill API</h2>
              </div>
              <span className="relative flex h-2 w-2">
                <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${accessibilityActive && autofillServiceActive ? 'bg-emerald-400' : 'bg-amber-400'}`}></span>
                <span className={`relative inline-flex rounded-full h-2 w-2 ${accessibilityActive && autofillServiceActive ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
              </span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Enable the native simulated background services below. This instructs the virtual operating system sandbox to look for focused credentials inputs on third-party mobile applications and reveal automated credential overlay capsules.
            </p>

            {/* Simulated System API toggles */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <button
                onClick={() => setAccessibilityActive(!accessibilityActive)}
                className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all select-none cursor-pointer ${
                  accessibilityActive 
                    ? "bg-emerald-550/5 border-emerald-500/20 text-emerald-400" 
                    : "bg-slate-950 border-slate-900 text-slate-500 hover:border-slate-800"
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span className="text-[10px] font-bold tracking-wider uppercase font-mono">Accessibility Bridge</span>
                  <span className={`text-[9px] px-1.5 py-0.2 rounded font-mono ${accessibilityActive ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-900 text-slate-500'}`}>
                    {accessibilityActive ? "ON" : "OFF"}
                  </span>
                </div>
                <span className="text-[9px] text-slate-400 mt-2 block leading-snug">
                  Scans target screen layouts securely for credentials inputs
                </span>
              </button>

              <button
                onClick={() => setAutofillServiceActive(!autofillServiceActive)}
                className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all select-none cursor-pointer ${
                  autofillServiceActive 
                    ? "bg-emerald-550/5 border-emerald-500/20 text-emerald-400" 
                    : "bg-slate-950 border-slate-900 text-slate-500 hover:border-slate-800"
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span className="text-[10px] font-bold tracking-wider uppercase font-mono">Autofill Framework</span>
                  <span className={`text-[9px] px-1.5 py-0.2 rounded font-mono ${autofillServiceActive ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-900 text-slate-500'}`}>
                    {autofillServiceActive ? "ON" : "OFF"}
                  </span>
                </div>
                <span className="text-[9px] text-slate-400 mt-2 block leading-snug">
                  Injects matching emails &amp; passwords with secure physical IPC
                </span>
              </button>
            </div>

            {/* Target App Simulation Selector */}
            <div className="space-y-2 pt-2 border-t border-slate-800/40">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-mono">Target App to Autofill Simulator:</span>
              <div className="grid grid-cols-4 gap-2">
                {(["instagram", "telegram", "google", "paypal"] as const).map(app => (
                  <button
                    key={app}
                    onClick={() => {
                      setSelectedMockTarget(app);
                      setMockEmailInput("");
                      setMockPasswordInput("");
                    }}
                    className={`py-1.5 px-2 rounded-xl text-[10px] font-black uppercase text-center transition-all cursor-pointer ${
                      selectedMockTarget === app 
                        ? "bg-slate-800 text-emerald-400 border border-emerald-500/30" 
                        : "bg-slate-950 text-slate-400 hover:bg-slate-900 border border-transparent"
                    }`}
                  >
                    {app}
                  </button>
                ))}
              </div>
            </div>

            {/* Live Render of target phone app logins */}
            <div className="bg-slate-950 border border-slate-900 rounded-3xl p-5 relative overflow-hidden transition-all duration-300">
              <div className="absolute top-2 right-2 flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                <span className="text-[8px] font-mono text-slate-600 uppercase">External App Isolation Screen</span>
              </div>

              {/* simulated target phone screen */}
              {selectedMockTarget === "instagram" && (
                <div className="space-y-3.5 py-3">
                  <div className="text-center">
                    <h3 className="font-serif italic font-bold tracking-tight text-lg leading-none bg-gradient-to-r from-purple-400 via-pink-500 to-amber-500 bg-clip-text text-transparent">Instagram</h3>
                    <p className="text-[9px] text-slate-500 mt-1">Simulated App ID: com.instagram.android</p>
                  </div>
                  <div className="space-y-2">
                    <input 
                      type="text" 
                      placeholder="Username or email" 
                      value={mockEmailInput}
                      onChange={(e) => setMockEmailInput(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-300 focus:outline-none focus:border-slate-700 font-sans"
                    />
                    <div className="relative">
                      <input 
                        type="password" 
                        placeholder="Password" 
                        value={mockPasswordInput}
                        onChange={(e) => setMockPasswordInput(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-300 focus:outline-none focus:border-slate-700 font-mono"
                      />
                    </div>
                  </div>
                  <button className="w-full bg-sky-500/10 text-sky-400 border border-sky-500/20 py-2 rounded-xl text-[11px] font-bold">
                    Log In
                  </button>
                </div>
              )}

              {selectedMockTarget === "telegram" && (
                <div className="space-y-3.5 py-3">
                  <div className="text-center">
                    <h3 className="font-bold tracking-tight text-base text-[#229ED9] flex items-center gap-1.5 justify-center">
                      <Send className="w-4 h-4 text-[#229ED9]" /> telegram
                    </h3>
                    <p className="text-[9px] text-slate-500 mt-1">Simulated App ID: org.telegram.messenger</p>
                  </div>
                  <div className="space-y-2 font-mono text-center">
                    <p className="text-[10px] text-slate-400">Secure Channel Auth Credentials</p>
                    <input 
                      type="text" 
                      placeholder="Admin login code / mobile" 
                      value={mockEmailInput}
                      onChange={(e) => setMockEmailInput(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-300 text-center focus:outline-none focus:border-slate-700 font-sans"
                    />
                    <input 
                      type="password" 
                      placeholder="Admin vault code" 
                      value={mockPasswordInput}
                      onChange={(e) => setMockPasswordInput(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-300 text-center focus:outline-none focus:border-slate-700 font-mono"
                    />
                  </div>
                  <button className="w-full bg-[#229ED9]/10 text-[#229ED9] border border-[#229ED9]/20 py-2 rounded-xl text-[11px] font-bold">
                    Authenticate Secure Socket
                  </button>
                </div>
              )}

              {selectedMockTarget === "google" && (
                <div className="space-y-3.5 py-3">
                  <div className="text-left">
                    <span className="text-xs font-bold text-slate-300 block">Sign in with Google</span>
                    <span className="text-[9px] text-[red]/80">to continue to Chrome Core (Simulated iOS Secure Node)</span>
                  </div>
                  <div className="space-y-2">
                    <input 
                      type="email" 
                      placeholder="Email or phone" 
                      value={mockEmailInput}
                      onChange={(e) => setMockEmailInput(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-300 focus:outline-none focus:border-slate-700 font-sans"
                    />
                    <input 
                      type="password" 
                      placeholder="Enter password" 
                      value={mockPasswordInput}
                      onChange={(e) => setMockPasswordInput(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-300 focus:outline-none focus:border-slate-700 font-mono"
                    />
                  </div>
                  <div className="flex justify-between items-center text-[10px]">
                    <span className="text-blue-400 cursor-pointer">Create Account</span>
                    <button className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-1.5 rounded-xl">Next</button>
                  </div>
                </div>
              )}

              {selectedMockTarget === "paypal" && (
                <div className="space-y-3.5 py-3">
                  <div className="text-center">
                    <span className="text-lg font-black tracking-wider text-sky-300 italic">PayPal</span>
                    <p className="text-[9px] text-slate-500">Simulated Safe Checkout Module</p>
                  </div>
                  <div className="space-y-2">
                    <input 
                      type="email" 
                      placeholder="PayPal email address" 
                      value={mockEmailInput}
                      onChange={(e) => setMockEmailInput(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-300 focus:outline-none"
                    />
                    <input 
                      type="password" 
                      placeholder="Security code" 
                      value={mockPasswordInput}
                      onChange={(e) => setMockPasswordInput(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-300 focus:outline-none"
                    />
                  </div>
                  <button className="w-full bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-bold py-2 rounded-xl text-[11px]">
                    Pay Safely in One Touch
                  </button>
                </div>
              )}

              {/* SECURE AUTO-FILL OVERLAY COMPONENT (triggers if autofill active & accessibility scans detect matching) */}
              {autofillServiceActive && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  className="absolute bottom-2 inset-x-2 bg-emerald-950/95 border border-emerald-500/30 rounded-2xl p-3 shadow-2xl backdrop-blur-md z-20 flex flex-col gap-2 shadow-emerald-950"
                >
                  <div className="flex items-center justify-between text-[9px] text-emerald-300 font-bold">
                    <span className="flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-emerald-400" />
                      SLATE AUTO-FILL PROMPT
                    </span>
                    <span className="text-slate-500 font-mono">Accessibility Scan Active</span>
                  </div>

                  {/* Find matching account in users current hydrated vault */}
                  {items.filter(item => {
                    const matchedSig = getMatchedPlatformSpec(item.title);
                    if (matchedSig) {
                      return selectedMockTarget.includes(matchedSig.name.split(" ")[0].toLowerCase());
                    }
                    return item.title.toLowerCase().includes(selectedMockTarget);
                  }).length > 0 ? (
                    items.filter(item => {
                      const matchedSig = getMatchedPlatformSpec(item.title);
                      if (matchedSig) {
                        return selectedMockTarget.includes(matchedSig.name.split(" ")[0].toLowerCase());
                      }
                      return item.title.toLowerCase().includes(selectedMockTarget);
                    }).slice(0, 1).map(item => (
                      <button
                        key={item.id}
                        onClick={() => handleAutofillAction(item)}
                        className="bg-emerald-600/90 hover:bg-emerald-500 text-white p-2 rounded-xl text-[10px] font-black tracking-wider uppercase flex items-center justify-between transition-all cursor-pointer"
                      >
                        <span>Fill {item.emailOrUsername}</span>
                        <span className="bg-slate-950/40 text-[8px] font-bold px-2 py-0.5 rounded-full">Secure One-Tap</span>
                      </button>
                    ))
                  ) : (
                    <div className="space-y-2">
                      <p className="text-[9px] text-slate-400 leading-normal">
                        No direct vault record found for <strong className="text-slate-200">"{selectedMockTarget}"</strong> catalog. You can force-fill the target email/password by selecting any credential from the Simulator Vault screen.
                      </p>
                      <div className="flex flex-wrap gap-1">
                        {items.slice(0, 3).map(seed => (
                          <button
                            key={seed.id}
                            onClick={() => handleAutofillAction(seed)}
                            className="text-[9px] bg-slate-900 border border-slate-800 text-emerald-400 hover:text-white hover:border-emerald-500/40 px-2 py-1 rounded transition-all"
                            title="Force autofill this"
                          >
                            Fill As: {seed.title}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </motion.div>
              )}
            </div>
          </div>

          {/* Dynamic Interactive Bridge Swift/Kotlin reference specs */}
          <div className="bg-slate-900/30 border border-slate-900 rounded-3xl p-5 space-y-3.5 text-left">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="text-xs font-bold text-slate-300 flex items-center gap-1.5 uppercase font-mono">
                <FileText className="w-3.5 h-3.5 text-slate-400" />
                Structural Native Bridge Specs
              </h3>

              <div className="flex bg-slate-950 rounded-lg p-0.5 border border-slate-950">
                <button
                  onClick={() => setSelectedCodeSpec("android")}
                  className={`px-2 py-1 rounded text-[8px] font-bold ${selectedCodeSpec === 'android' ? 'bg-slate-800 text-emerald-400' : 'text-slate-500'}`}
                >
                  Android
                </button>
                <button
                  onClick={() => setSelectedCodeSpec("ios")}
                  className={`px-2 py-1 rounded text-[8px] font-bold ${selectedCodeSpec === 'ios' ? 'bg-slate-800 text-emerald-400' : 'text-slate-500'}`}
                >
                  Apple iOS
                </button>
              </div>
            </div>

            <p className="text-[10px] text-slate-400 leading-relaxed">
              Below is the actual platform-specific implementation schema representing how our React Native secure password vault initiates Auto-Fill bindings natively via Swift / Kotlin.
            </p>

            <div className="bg-slate-950 rounded-2xl p-3.5 font-mono text-[9px] text-slate-400 leading-relaxed border border-slate-900 overflow-x-auto select-all max-h-[180px] overflow-y-auto">
              {selectedCodeSpec === "android" ? (
                <pre>{`// Kotlin Android Autofill Service Framework integration
package com.slate.password.manager

import android.service.autofill.AutofillService
import android.service.autofill.Dataset
import android.service.autofill.FillRequest
import android.service.autofill.FillResponse
import android.view.autofill.AutofillValue

class SlateAutofillEngine : AutofillService() {
    override fun onFillRequest(
        request: FillRequest,
        cancellation: CancellationSignal,
        callback: FillCallback
    ) {
        val structure = request.fillContexts.last().structure
        val parsedForm = parseStructure(structure) // recursive parser nodes
        
        val secureVault = OfflineVaultDeriver(this)
        val creds = secureVault.queryByPackage(parsedForm.targetPackageName)

        val response = FillResponse.Builder()
        if (creds != null) {
            val dataset = Dataset.Builder()
                .setValue(parsedForm.emailId, AutofillValue.forText(creds.email))
                .setValue(parsedForm.passwordId, AutofillValue.forText(creds.plainPw))
                .build()
            response.addDataset(dataset)
        }
        callback.onSuccess(response.build())
    }
}`}</pre>
              ) : (
                <pre>{`// Swift iOS Auto-Fill Credentials Provider
import AuthenticationServices
import LocalAuthentication

class SlateCredentialProvider: ASCredentialProviderViewController {
    
    override func prepareCredentialList(for serviceIdentifiers: [ASCredentialServiceIdentifier]) {
        // Query locked local sqlite vault
        let rawPackage = serviceIdentifiers.first?.identifier
        let vault = SlateSecureLocalDatabase.shared
        
        if let account = vault.retrieveMatchedAccount(packageName: rawPackage) {
            let item = ASPasswordCredentialIdentity(
                serviceIdentifier: serviceIdentifiers.first!,
                user: account.username,
                recordIdentifier: account.id
            )
            self.extensionContext.setPendingCredentials([item])
        }
    }
    
    override func provideCredentialWithoutUserInteraction(_ credential: ASCredentialIdentity) {
        // Bio-metrics authentication fallback
        let authContext = LAContext()
        authContext.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, reason: "Derive secure AES key") { [weak self] success, error in
            if success {
                let plainPassword = self?.vault.decryptAndFetch(id: credential.recordIdentifier)
                self?.extensionContext.completeRequest(withSelectedCredential: plainPassword)
            }
        }
    }
}`}</pre>
              )}
            </div>
          </div>
        </section>

        {/* RIGHT COLUMN: Slate Emerald Mobile Device Simulator (7 columns on desktop) */}
        <section className="lg:col-span-7 flex flex-col items-center">
          
          {/* Simulated Mobile Device Frame Container */}
          <div className="w-full max-w-sm bg-slate-900 border-[7px] border-slate-800 rounded-[3rem] shadow-2xl relative overflow-hidden flex flex-col border border-emerald-500/5 aspect-[9/18]">
            {/* Phone Notch */}
            <div className="absolute top-0 inset-x-0 h-6 bg-slate-900 rounded-b-2xl z-50 flex items-center justify-center">
              <span className="w-12 h-3.5 bg-black rounded-full block border border-slate-800/20" />
            </div>

            {/* Simulated Phone Status Bar */}
            <div className="bg-slate-950 px-5 pt-7 pb-2 flex justify-between items-center text-[10px] font-mono font-medium text-slate-500 z-40 select-none">
              <span>12:28 PM</span>
              <div className="flex items-center gap-1.5">
                <Smartphone className="w-2.5 h-2.5 text-emerald-400" />
                <span className="text-[8px] bg-emerald-500/10 text-emerald-400 px-1 rounded border border-emerald-500/20 font-bold">5G</span>
                <span>100% DEP</span>
              </div>
            </div>

            {/* Simulated App Area View */}
            <div className="flex-1 overflow-y-auto flex flex-col bg-slate-950 relative w-full" id="mobile-app-canvas">
              
              {/* Slate Emerald App Header */}
              <div className="p-4 bg-slate-900 border-b border-slate-900 flex justify-between items-center sticky top-0 z-30">
                <div className="flex items-center gap-2">
                  <div className="p-1 px-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="text-left leading-normal">
                    <h2 className="text-xs font-black uppercase text-white tracking-widest font-mono">Slate Secure</h2>
                    <span className="text-[8px] text-emerald-400 font-bold block">ACTIVE HANDSHAKE</span>
                  </div>
                </div>

                <div className="flex items-center gap-1 bg-slate-950 rounded-lg p-1 border border-slate-800/50">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[8px] font-mono text-slate-400 font-bold">SECURE EXT</span>
                </div>
              </div>

              {/* Dynamic simulated views according to active mobile tab state */}
              <div className="flex-1 p-4 relative z-20 space-y-4">

                {/* TAB 1: Vault List Screen */}
                {activeMobileTab === "vault" && (
                  <div className="space-y-4">
                    
                    {/* Add/Edit modal nested flow inside device viewport */}
                    {isAdding || isEditing ? (
                      <div className="bg-slate-900 p-4 border border-slate-800/80 rounded-2xl text-left space-y-3">
                        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                          <span className="text-[10px] uppercase font-bold text-slate-300">
                            {isAdding ? "Seal New Identity" : "Amend Sealed Record"}
                          </span>
                          <button 
                            onClick={() => {
                              setIsAdding(false);
                              setIsEditing(false);
                            }}
                            className="text-slate-500 hover:text-slate-300 transition-colors"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <form onSubmit={handleSaveItem} className="space-y-3 text-left">
                          <div className="space-y-1">
                            <label className="text-[9px] font-bold text-slate-400 block uppercase">Title / App Name*</label>
                            <input
                              type="text"
                              required
                              value={formTitle}
                              onChange={(e) => setFormTitle(e.target.value)}
                              placeholder="e.g. Telegram Messenger, Stripe Accounts"
                              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-500/40 font-semibold"
                            />
                            {formTitle && getMatchedPlatformSpec(formTitle) && (
                              <div className="flex items-center gap-1.5 text-[8px] bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 px-2 py-0.5 rounded-lg font-mono">
                                <Sparkles className="w-2.5 h-2.5" />
                                MATCHED SPECIFICATION: {getMatchedPlatformSpec(formTitle)?.name}
                              </div>
                            )}
                          </div>

                          <div className="space-y-1">
                            <label className="text-[9px] font-bold text-slate-400 block uppercase">Email / Username*</label>
                            <input
                              type="text"
                              required
                              value={formEmailOrUsername}
                              onChange={(e) => setFormEmailOrUsername(e.target.value)}
                              placeholder="login email or profile handler"
                              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-500/40 font-mono"
                            />
                          </div>

                          <div className="space-y-1">
                            <div className="flex items-center justify-between">
                              <label className="text-[9px] font-bold text-slate-400 block uppercase">Secure Password*</label>
                              <button
                                type="button"
                                onClick={() => {
                                  // Assign inline standard password
                                  const characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()";
                                  let res = "";
                                  for(let i=0; i<16; i++) {
                                    res += characters.charAt(Math.floor(Math.random() * characters.length));
                                  }
                                  handleFormPasswordChange(res);
                                }}
                                className="text-[9px] text-emerald-450 hover:text-emerald-300 font-bold flex items-center gap-0.5"
                              >
                                <Sparkles className="w-2.5 h-2.5" /> Generate
                              </button>
                            </div>
                            <input
                              type="text"
                              required
                              value={formPassword}
                              onChange={(e) => handleFormPasswordChange(e.target.value)}
                              placeholder="Safe sealed keyphrase"
                              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-xs text-emerald-400 focus:outline-none focus:border-emerald-500/40 font-mono"
                            />

                            {formPassword && (
                              <div className="bg-slate-950 p-2 border border-slate-800/80 rounded-xl space-y-1 select-none text-[8px]">
                                <div className="flex items-center justify-between text-slate-500">
                                  <span>Entropy Score: {formPasswordStrength.score}/100</span>
                                  <span className="uppercase font-bold text-emerald-400">{formPasswordStrength.strength}</span>
                                </div>
                                <div className="h-1 bg-slate-900 rounded-full overflow-hidden">
                                  <div 
                                    className={`h-full ${formPasswordStrength.strength === 'strong' ? 'bg-emerald-500' : formPasswordStrength.strength === 'moderate' ? 'bg-amber-500' : 'bg-red-500'}`}
                                    style={{ width: `${formPasswordStrength.score}%` }}
                                  />
                                </div>
                              </div>
                            )}
                          </div>

                          <div className="space-y-1">
                            <label className="text-[9px] font-bold text-slate-400 block uppercase">Manual Category Index</label>
                            <select
                              value={formCategory}
                              onChange={(e) => setFormCategory(e.target.value as any)}
                              className="w-full bg-slate-950 border border-slate-800 text-slate-300 rounded-xl p-2 text-xs focus:outline-none"
                            >
                              <option value="social">💬 Social Networks</option>
                              <option value="personal">🔒 Identity &amp; Auth</option>
                              <option value="work">💼 Work Operations</option>
                              <option value="financial">💳 Cards &amp; Vaults</option>
                              <option value="shopping">🛒 Commerce &amp; Shopping</option>
                              <option value="other">⚙️ Loose Ends / Other</option>
                            </select>
                          </div>

                          <div className="space-y-1">
                            <label className="text-[9px] font-bold text-slate-400 block uppercase">Secured Notes</label>
                            <textarea
                              rows={2}
                              value={formNotes}
                              onChange={(e) => setFormNotes(e.target.value)}
                              placeholder="e.g. recovery PINs or static seeds"
                              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-xs text-slate-300 focus:outline-none resize-none"
                            />
                          </div>

                          {formError && (
                            <p className="text-[9px] text-red-400 font-bold">{formError}</p>
                          )}

                          <div className="flex gap-1.5 justify-end pt-2">
                            <button
                              type="button"
                              onClick={() => {
                                setIsAdding(false);
                                setIsEditing(false);
                              }}
                              className="px-3 py-1.5 bg-slate-950 text-slate-400 hover:text-white rounded-xl text-[10px] font-bold cursor-pointer"
                            >
                              Cancel
                            </button>
                            <button
                              type="submit"
                              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-[10px] font-black uppercase tracking-wider cursor-pointer"
                            >
                              Store Sealed File
                            </button>
                          </div>
                        </form>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {/* Compact Search Suite Inside Virtual Screen */}
                        <div className="flex items-center gap-1.5">
                          <div className="relative flex-1">
                            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
                            <input 
                              type="text"
                              value={searchQuery}
                              onChange={(e) => setSearchQuery(e.target.value)}
                              placeholder="Search credentials, tags..."
                              className="w-full bg-slate-900 border border-slate-800 rounded-xl py-1.5 pl-8 pr-3 text-[10px] text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500/40"
                            />
                            {searchQuery && (
                              <button 
                                onClick={() => setSearchQuery("")}
                                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500"
                              >
                                <X className="w-2.5 h-2.5" />
                              </button>
                            )}
                          </div>

                          <button
                            onClick={openAddModal}
                            className="p-1 px-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-[10px] font-black uppercase tracking-widest cursor-pointer inline-flex items-center gap-1"
                            title="Add item"
                          >
                            <Plus className="w-3.5 h-3.5" /> Add
                          </button>
                        </div>

                        {/* Quick filter pill shelf inside virtual screen */}
                        <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-none select-none">
                          {Object.entries(CATEGORY_LABELS).map(([key, label]) => (
                            <button
                              key={key}
                              onClick={() => setSelectedCategory(key as CategoryType)}
                              className={`px-2 py-1 rounded-xl text-[9px] font-black tracking-wide uppercase whitespace-nowrap transition-all border cursor-pointer ${
                                selectedCategory === key 
                                  ? "bg-emerald-550/10 text-emerald-400 border-emerald-555/40 font-bold" 
                                  : "bg-slate-950 border-transparent text-slate-500 hover:text-slate-350"
                              }`}
                            >
                              {label}
                            </button>
                          ))}
                        </div>

                        {/* List Area */}
                        <div className="space-y-2 max-h-[290px] overflow-y-auto pr-1">
                          {filteredItems.length === 0 ? (
                            <div className="text-center py-10 space-y-1.5 border border-dashed border-slate-900 rounded-2xl bg-slate-950/40">
                              <Lock className="w-6 h-6 text-slate-700 mx-auto" />
                              <p className="text-[10px] text-slate-500">No passwords fit this description.</p>
                              <button 
                                onClick={openAddModal}
                                className="text-[10px] text-emerald-400 underline font-black uppercase tracking-wider block mx-auto cursor-pointer"
                              >
                                Add credentials
                              </button>
                            </div>
                          ) : (
                            filteredItems.map(item => {
                              // Auto-detect brand specification
                              const matchedBrand = getMatchedPlatformSpec(item.title);
                              return (
                                <div
                                  key={item.id}
                                  onClick={() => {
                                    setSelectedItem(selectedItem?.id === item.id ? null : item);
                                  }}
                                  className={`p-3 rounded-2xl border transition-all text-left cursor-pointer space-y-2 relative overflow-hidden group ${
                                    selectedItem?.id === item.id
                                      ? "bg-slate-900 border-slate-700 shadow-md"
                                      : "bg-slate-950 border-slate-900 hover:border-slate-800"
                                  }`}
                                >
                                  {/* Matched colored left accent */}
                                  <div 
                                    className="absolute left-0 top-0 bottom-0 w-1" 
                                    style={{ backgroundColor: matchedBrand ? matchedBrand.brandColor : "#10b981" }}
                                  />

                                  <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-2 pl-1">
                                      {/* Micro logo placeholder badge matched dynamically using automated icon triggers */}
                                      <div className={`p-1 rounded-lg text-xs font-black uppercase tracking-tight flex items-center justify-center font-mono select-none ${
                                        matchedBrand ? `${matchedBrand.bgColor} ${matchedBrand.borderColor} border` : "bg-emerald-500/10 text-emerald-400 border border-emerald-500/10"
                                      }`}
                                      style={{ color: matchedBrand?.brandColor }}
                                      >
                                        {item.title.substring(0, 2)}
                                      </div>
                                      
                                      <div className="text-left">
                                        <h4 className="text-[10px] font-extrabold text-slate-100 flex items-center gap-1">
                                          {item.title}
                                          {matchedBrand && (
                                            <span 
                                              className="w-1.5 h-1.5 rounded-full inline-block"
                                              style={{ backgroundColor: matchedBrand.brandColor }}
                                              title="Official brand matching activated"
                                            />
                                          )}
                                        </h4>
                                        <span className="text-[8px] text-slate-500 block font-mono leading-none">{item.emailOrUsername}</span>
                                      </div>
                                    </div>

                                    {/* Score badge */}
                                    <span className={`text-[8px] font-black uppercase py-0.5 px-1.5 rounded-lg border font-mono tracking-wider ${
                                      item.strength === 'strong' 
                                        ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" 
                                        : item.strength === 'moderate' 
                                          ? "bg-amber-500/10 text-amber-400 border-amber-500/20"
                                          : "bg-red-500/10 text-red-400 border-red-500/20"
                                    }`}>
                                      {item.strength}
                                    </span>
                                  </div>

                                  {/* Timestamp displays: Created At & Last Modified At Metadata Tracking on detail drop */}
                                  {selectedItem?.id === item.id && (
                                    <motion.div 
                                      initial={{ opacity: 0, height: 0 }}
                                      animate={{ opacity: 1, height: "auto" }}
                                      className="pt-2.5 border-t border-slate-800 space-y-2.5 text-xs text-slate-400 text-left select-none font-sans"
                                    >
                                      {/* Password control string view row */}
                                      <div className="space-y-1">
                                        <span className="text-[9px] uppercase font-bold text-slate-500 block">Encrypted Password Secret:</span>
                                        <div className="flex items-center justify-between gap-1.5 bg-slate-950 p-2 rounded-xl border border-slate-900 font-mono text-xs text-emerald-400 tracking-wide select-all">
                                          <span className="truncate">
                                            {decryptedPasswords[item.id] ? decryptedPasswords[item.id] : "••••••••••••"}
                                          </span>
                                          <div className="flex items-center gap-1 shrink-0">
                                            <button
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                handleDecrypt(item.encryptedPassword, item.id);
                                              }}
                                              className="p-1 hover:bg-slate-900 rounded text-slate-500 hover:text-slate-350"
                                              title="Decipher plain text key"
                                            >
                                              {decryptedPasswords[item.id] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                                            </button>
                                            <button
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                if (decryptedPasswords[item.id]) {
                                                  handleCopy(decryptedPasswords[item.id], `${item.id}-copy`);
                                                } else {
                                                  // decrypt and copy then warn
                                                  decryptText(item.encryptedPassword, masterPassword).then(dec => handleCopy(dec, `${item.id}-copy`));
                                                }
                                              }}
                                              className="p-1 hover:bg-slate-900 rounded text-slate-500 hover:text-emerald-400"
                                              title="Copy decryption secret"
                                            >
                                              {copyStatus[`${item.id}-copy`] ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                                            </button>
                                          </div>
                                        </div>
                                      </div>

                                      {/* Autofill virtual action prompt inside simulate view */}
                                      <div className="flex gap-1.5">
                                        <button
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            handleAutofillAction(item);
                                          }}
                                          className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-[9px] uppercase tracking-wider py-1.5 rounded-xl transition-all shadow-md cursor-pointer flex items-center justify-center gap-1"
                                        >
                                          <Smartphone className="w-3 h-3" />
                                          Autofill Target Form
                                        </button>
                                        <button
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            openEditModal(item);
                                          }}
                                          className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-[9px] uppercase tracking-wide px-3 py-1.5 rounded-xl transition-colors cursor-pointer"
                                        >
                                          Edit
                                        </button>
                                        <button
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            handleDeleteItem(item.id);
                                          }}
                                          className="bg-red-950/40 hover:bg-red-900/30 text-red-500 font-bold text-[9px] uppercase px-3 py-1.5 rounded-xl transition-colors cursor-pointer"
                                        >
                                          Wipe
                                        </button>
                                      </div>

                                      {item.notes && (
                                        <p className="text-[9px] text-slate-500 italic leading-snug">"{item.notes}"</p>
                                      )}

                                      {/* METADATA TRACKING: Created At & Last Modified At displays */}
                                      <div className="grid grid-cols-2 gap-1.5 pt-2 border-t border-slate-900 text-[8px] font-mono select-none text-slate-500">
                                        <div className="space-y-0.5 text-left">
                                          <span className="text-[7px] uppercase text-slate-600 block flex items-center gap-0.5">
                                            <Clock className="w-2 h-2" /> Created At:
                                          </span>
                                          <span className="truncate block font-semibold hover:text-slate-400">
                                            {new Date(item.createdAt).toLocaleDateString("en-US", { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                                          </span>
                                        </div>
                                        <div className="space-y-0.5 text-left">
                                          <span className="text-[7px] uppercase text-slate-600 block flex items-center gap-0.5">
                                            <RefreshCw className="w-2 h-2" /> Last Modified At:
                                          </span>
                                          <span className="truncate block font-semibold text-emerald-500/80">
                                            {item.lastModifiedAt ? new Date(item.lastModifiedAt).toLocaleDateString("en-US", { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : "Never modified"}
                                          </span>
                                        </div>
                                      </div>
                                    </motion.div>
                                  )}
                                </div>
                              );
                            })
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* TAB 2: Entropy Generator Panel inside phone */}
                {activeMobileTab === "generator" && (
                  <div className="space-y-4">
                    <PasswordGenerator 
                      onUsePassword={handleUseGeneratedPasswordInForm} 
                      inline={true} 
                    />
                  </div>
                )}

                {/* TAB 3: Guard Dashboard & Expert Cyber Advisor */}
                {activeMobileTab === "guard" && (
                  <div className="space-y-4 text-left">
                    
                    {/* Security Audit panel inside phone */}
                    <div className="grid grid-cols-2 gap-2 select-none">
                      <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 flex flex-col justify-between">
                        <span className="text-[8px] text-slate-400 uppercase font-black tracking-wide leading-none">Security Rating</span>
                        <div className="flex items-baseline gap-1 mt-1.5">
                          <span className="text-sm font-black text-emerald-400">
                            {calculateStats.total > 0 
                              ? Math.round(((calculateStats.strongCount * 1.0 + calculateStats.moderateCount * 0.5) / calculateStats.total) * 100)
                              : 100}%
                          </span>
                          <span className="text-[7px] text-slate-600">Integrity</span>
                        </div>
                      </div>

                      <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 flex flex-col justify-between">
                        <span className="text-[8px] text-red-400 uppercase font-black tracking-wide leading-none">Active Risks</span>
                        <div className="flex items-baseline gap-2 mt-1.5">
                          <span className="text-sm font-black text-red-500">{calculateStats.weakCount}</span>
                          {calculateStats.reusedCount > 0 && (
                            <span className="text-[7px] text-amber-500 font-bold font-mono">Reused: {calculateStats.reusedCount}</span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Gemini Cyber Guard Assistant chat shell inside screen */}
                    <div className="bg-slate-900 border border-slate-800/80 rounded-2xl p-3 space-y-3 flex flex-col h-[280px]">
                      <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                        <span className="text-[9px] font-black uppercase text-slate-300 flex items-center gap-1">
                          <BrainCircuit className="w-3.5 h-3.5 text-emerald-400" />
                          Slate AI Guard Advisor
                        </span>
                        <span className="text-[7px] font-mono text-slate-500">v3.5 Flash Connected</span>
                      </div>

                      {/* Messages scroll zone */}
                      <div className="flex-1 overflow-y-auto space-y-2 max-h-[170px] pr-1 scrollbar-none">
                        {chatMessages.map(msg => (
                          <div 
                            key={msg.id}
                            className={`p-2 rounded-xl text-[9px] leading-relaxed text-left max-w-[85%] ${
                              msg.role === 'user' 
                                ? "bg-emerald-600 text-white ml-auto rounded-tr-none" 
                                : "bg-slate-950 text-slate-300 mr-auto rounded-tl-none border border-slate-900"
                            }`}
                          >
                            <p className="whitespace-pre-line">{msg.content}</p>
                            <span className="text-[6px] text-slate-500 block text-right mt-1 select-none font-mono">
                              {msg.timestamp}
                            </span>
                          </div>
                        ))}
                        {chatLoading && (
                          <div className="bg-slate-950 text-slate-400 p-2 rounded-xl text-[9px] mr-auto border border-slate-900 flex items-center gap-1">
                            <RefreshCw className="w-3 h-3 animate-spin text-emerald-400" />
                            Consulting cipher logs...
                          </div>
                        )}
                        {chatError && (
                          <div className="text-[8px] text-red-400 p-2 rounded-xl bg-red-950/25 border border-red-900/30">
                            {chatError}
                          </div>
                        )}
                      </div>

                      {/* Input row */}
                      <form onSubmit={handleSendChatMessage} className="flex gap-1 pt-1.5 border-t border-slate-800 select-all">
                        <input
                          type="text"
                          value={chatInput}
                          onChange={(e) => setChatInput(e.target.value)}
                          placeholder="Audit password '123456'..."
                          className="flex-1 bg-slate-950 border border-slate-800 rounded-lg py-1 px-2.5 text-[9px] text-slate-300 focus:outline-none focus:border-emerald-500/40"
                        />
                        <button
                          type="submit"
                          disabled={chatLoading}
                          className="bg-emerald-600 hover:bg-emerald-500 p-1 px-3 text-[9px] font-bold uppercase text-white rounded-lg cursor-pointer"
                        >
                          Ask
                        </button>
                      </form>
                    </div>

                  </div>
                )}

                {/* TAB 4: Framework Settings & Telemetry Status */}
                {activeMobileTab === "settings" && (
                  <div className="space-y-3.5 text-left">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-mono">Framework Details</span>
                    
                    <div className="bg-slate-900 border border-slate-800/80 rounded-2xl p-4 space-y-3 font-mono text-[9px] text-slate-400">
                      <div className="flex justify-between border-b border-slate-800 pb-1.5">
                        <span>Local Vault Encryption:</span>
                        <span className="text-emerald-400 font-bold uppercase">AES-GCM-256</span>
                      </div>
                      <div className="flex justify-between border-b border-slate-800 pb-1.5">
                        <span>Entropy Deriver Iterations:</span>
                        <span className="text-slate-350">10,000 PBKDF2</span>
                      </div>
                      <div className="flex justify-between border-b border-slate-800 pb-1.5">
                        <span>Database Storage Type:</span>
                        <span className="text-slate-350">LocalStorage Cipher</span>
                      </div>
                      <div className="flex justify-between border-b border-slate-800 pb-1.5">
                        <span>Access Signature Provider:</span>
                        <span className="text-slate-300">AccessibilityService-12</span>
                      </div>
                      <div className="flex justify-between text-slate-500 select-none">
                        <span>Current Active Workspace:</span>
                        <span>0.0.0.0:3000</span>
                      </div>
                    </div>

                    <div className="bg-emerald-950/20 border border-emerald-500/20 rounded-xl p-3 text-[8.5px] text-emerald-400 leading-relaxed text-center font-semibold">
                      🚀 <strong>System Capability Confirmed:</strong> Designed to satisfy both Apple ASNeeded provider requirements &amp; Android Autofill Service hooks securely with prompt-less micro IPC.
                    </div>
                  </div>
                )}

              </div>

              {/* Simulated Device Lock overlay fallback */}
              {!masterPassword && (
                <div className="absolute inset-0 bg-slate-950/95 backdrop-blur-sm z-40 flex flex-col items-center justify-center p-6 text-center">
                  <Lock className="w-8 h-8 text-emerald-500 animate-pulse mb-3" />
                  <p className="text-xs text-slate-400">Secure Vault Derived Locked.</p>
                </div>
              )}

              {/* Dynamic Overlay system notification container */}
              <AnimatePresence>
                {clipboardLeakedWarning && (
                  <motion.div 
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="absolute top-16 inset-x-4 bg-amber-950/90 border border-amber-900/35 p-2 rounded-xl text-[8.5px] text-amber-300 text-center font-mono select-none z-50 shadow-lg leading-normal"
                  >
                    ⚠️ {clipboardLeakedWarning}
                  </motion.div>
                )}
                
                {autofillToast && (
                  <motion.div 
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 30 }}
                    className="absolute bottom-16 inset-x-4 bg-emerald-900 border border-emerald-500/30 p-2.5 rounded-xl text-[9px] text-white text-center font-bold font-sans select-none z-50 shadow-xl shadow-slate-950"
                  >
                    🚀 {autofillToast}
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Simulated Bottom Tab Navigator Bar */}
              <nav className="bg-slate-900 border-t border-slate-900 sticky bottom-0 z-30 flex justify-around p-1 select-none">
                <button
                  onClick={() => {
                    setActiveMobileTab("vault");
                    setIsAdding(false);
                    setIsEditing(false);
                  }}
                  className={`flex flex-col items-center gap-1 py-1.5 text-[8.5px] font-black uppercase transition-all flex-1 cursor-pointer ${
                    activeMobileTab === "vault" ? "text-emerald-400 font-extrabold" : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  Vault
                </button>
                <button
                  onClick={() => {
                    setActiveMobileTab("generator");
                    setIsAdding(false);
                    setIsEditing(false);
                  }}
                  className={`flex flex-col items-center gap-1 py-1.5 text-[8.5px] font-black uppercase transition-all flex-1 cursor-pointer ${
                    activeMobileTab === "generator" ? "text-emerald-400 font-extrabold" : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  Generator
                </button>
                <button
                  onClick={() => {
                    setActiveMobileTab("guard");
                    setIsAdding(false);
                    setIsEditing(false);
                  }}
                  className={`flex flex-col items-center gap-1 py-1.5 text-[8.5px] font-black uppercase transition-all flex-1 cursor-pointer ${
                    activeMobileTab === "guard" ? "text-emerald-400 font-extrabold" : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  <BrainCircuit className="w-3.5 h-3.5" />
                  Advisor
                </button>
                <button
                  onClick={() => {
                    setActiveMobileTab("settings");
                    setIsAdding(false);
                    setIsEditing(false);
                  }}
                  className={`flex flex-col items-center gap-1 py-1.5 text-[8.5px] font-black uppercase transition-all flex-1 cursor-pointer ${
                    activeMobileTab === "settings" ? "text-emerald-400 font-extrabold" : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  Status
                </button>
              </nav>

            </div>
          </div>

          <p className="text-xs text-slate-500 mt-4 font-mono select-none">
            Simulator Sandbox Touch Interface Target: #mobile-app-canvas
          </p>
        </section>

      </main>

      {/* Decorative footer copyright card */}
      <footer className="py-8 border-t border-slate-900 bg-slate-950 mt-12 text-center text-xs text-slate-500 space-y-1 z-10 relative">
        <p className="font-semibold text-slate-400 uppercase tracking-widest font-mono text-[10px]">Slate Secure Ecosystem</p>
        <p className="text-[10px] text-slate-600">Cross-Platform Mobile Security Agent. Powered securely in Zero-Knowledge Web Sandbox.</p>
      </footer>
    </div>
  );
}
