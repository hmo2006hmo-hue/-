import { useState, useEffect, useCallback } from "react";
import { Copy, RefreshCw, Check, Sparkles, Sliders, Heading } from "lucide-react";
import { analyzePassword } from "../utils/crypto";
import { motion, AnimatePresence } from "motion/react";

const SECURE_WORDS = [
  "armor", "beacon", "castle", "desert", "emerald", "falcon", "glory", "haven", "infinite", "jungle",
  "knight", "lagoon", "matrix", "nebula", "oasis", "planet", "quasar", "radar", "shield", "tower",
  "unify", "vortex", "whisper", "xenon", "yacht", "zenith", "quantum", "gravity", "summit", "canyon"
];

interface PasswordGeneratorProps {
  onUsePassword?: (password: string) => void;
  inline?: boolean;
}

export default function PasswordGenerator({ onUsePassword, inline = false }: PasswordGeneratorProps) {
  const [activeTab, setActiveTab] = useState<"standard" | "phrase">("standard");
  const [length, setLength] = useState(16);
  const [includeUpper, setIncludeUpper] = useState(true);
  const [includeLower, setIncludeLower] = useState(true);
  const [includeNumbers, setIncludeNumbers] = useState(true);
  const [includeSymbols, setIncludeSymbols] = useState(true);
  
  // Phrase states
  const [phraseLength, setPhraseLength] = useState(4);
  const [phraseSeparator, setPhraseSeparator] = useState("-");
  const [phraseNumbers, setPhraseNumbers] = useState(true);

  const [generatedPassword, setGeneratedPassword] = useState("");
  const [copied, setCopied] = useState(false);

  const generateStandard = useCallback(() => {
    let charset = "";
    if (includeLower) charset += "abcdefghijklmnopqrstuvwxyz";
    if (includeUpper) charset += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if (includeNumbers) charset += "0123456789";
    if (includeSymbols) charset += "!@#$%^&*()_+-=[]{}|;:,.<>?";

    if (!charset) {
      setGeneratedPassword("");
      return;
    }

    let result = "";
    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * charset.length);
      result += charset[randomIndex];
    }
    setGeneratedPassword(result);
  }, [length, includeUpper, includeLower, includeNumbers, includeSymbols]);

  const generatePhrase = useCallback(() => {
    const wordPool = SECURE_WORDS;
    const selectedWords: string[] = [];

    for (let i = 0; i < phraseLength; i++) {
      const rWord = wordPool[Math.floor(Math.random() * wordPool.length)];
      selectedWords.push(rWord);
    }

    let result = selectedWords.join(phraseSeparator);

    if (phraseNumbers) {
      const randNum = Math.floor(10 + Math.random() * 900); // 2-3 digit number
      result += phraseSeparator + randNum;
    }

    setGeneratedPassword(result);
  }, [phraseLength, phraseSeparator, phraseNumbers]);

  const handleGenerate = useCallback(() => {
    if (activeTab === "standard") {
      generateStandard();
    } else {
      generatePhrase();
    }
  }, [activeTab, generateStandard, generatePhrase]);

  useEffect(() => {
    handleGenerate();
  }, [handleGenerate]);

  const handleCopy = () => {
    if (!generatedPassword) return;
    navigator.clipboard.writeText(generatedPassword);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const { score, strength, timeToCrack } = analyzePassword(generatedPassword);

  const getStrengthBadgeClass = () => {
    switch (strength) {
      case "strong":
        return "bg-emerald-500/10 text-emerald-400 border-emerald-500/20";
      case "moderate":
        return "bg-amber-500/10 text-amber-400 border-amber-500/20";
      default:
        return "bg-red-500/10 text-red-400 border-red-500/20";
    }
  };

  const getStrengthLabel = () => {
    switch (strength) {
      case "strong": return "Extremely Secure";
      case "moderate": return "Moderate Security";
      default: return "Weak / At Risk";
    }
  };

  return (
    <div id="password-gen-container" className={`bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 ${inline ? "" : "shadow-xl"}`}>
      <div className="flex items-center justify-between mb-4 border-b border-slate-800/60 pb-3">
        <h3 className="text-xs font-bold text-slate-200 flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
          Entropy Password Engine
        </h3>
        <div className="flex rounded-lg bg-slate-950 p-1 border border-slate-800/80">
          <button
            onClick={() => setActiveTab("standard")}
            className={`px-3 py-1 rounded-md text-[10px] font-bold select-none transition-all cursor-pointer ${
              activeTab === "standard" ? "bg-slate-800 text-emerald-400 shadow-sm" : "text-slate-400 hover:text-slate-200"
            }`}
          >
            Custom Charset
          </button>
          <button
            onClick={() => setActiveTab("phrase")}
            className={`px-3 py-1 rounded-md text-[10px] font-bold select-none transition-all cursor-pointer ${
              activeTab === "phrase" ? "bg-slate-800 text-emerald-400 shadow-sm" : "text-slate-400 hover:text-slate-200"
            }`}
          >
            Memorable Passphrase
          </button>
        </div>
      </div>

      <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-3.5 mb-4 flex items-center justify-between gap-3 font-mono relative overflow-hidden">
        <span className="text-emerald-400 font-bold select-all tracking-wide break-all text-xs md:text-sm text-left flex-1" id="generated-password-display">
          {generatedPassword || "Tap reload to generate..."}
        </span>
        <div className="flex items-center gap-1.5 shrink-0 z-10">
          <button
            onClick={handleCopy}
            title="Copy Password"
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded-lg transition-colors cursor-pointer"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>
          <button
            onClick={handleGenerate}
            title="Regenerate"
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded-lg transition-colors cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4 p-3.5 bg-slate-950/45 border border-slate-800/50 rounded-xl select-none">
        <div className="text-left flex flex-col justify-between">
          <div>
            <span className="text-[10px] font-semibold text-slate-400 block">Guaranteed Integrity:</span>
            <div className="flex items-center gap-1.5 mt-1">
              <span className={`px-2 py-0.5 rounded border text-[10px] font-bold uppercase ${getStrengthBadgeClass()}`}>
                {getStrengthLabel()}
              </span>
              <span className="text-[10px] text-slate-500 font-mono">Score: {score}/100</span>
            </div>
          </div>
          <div className="mt-2.5">
            <span className="text-[10px] font-semibold text-slate-400 block">Crack Difficulty Time:</span>
            <p className="text-xs font-bold text-slate-200 mt-0.5">{timeToCrack}</p>
          </div>
        </div>

        <div className="flex flex-col justify-end">
          <span className="text-[10px] font-semibold text-slate-400 mb-1">Strength Spectrum Indicator</span>
          <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden mt-1 text-right">
            <div 
              style={{ width: `${score}%` }}
              className={`h-full rounded-full transition-all duration-300 ${
                strength === "strong" ? "bg-emerald-500" : strength === "moderate" ? "bg-amber-500" : "bg-red-500"
              }`}
            />
          </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === "standard" ? (
          <motion.div
            key="standard"
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            transition={{ duration: 0.15 }}
            className="space-y-3.5 text-left"
          >
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-semibold text-slate-400">Length: <span className="text-emerald-400 font-bold">{length}</span> chars</span>
              </div>
              <input
                type="range"
                min="6"
                max="64"
                value={length}
                onChange={(e) => setLength(parseInt(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer bg-slate-800 h-1 rounded-lg appearance-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5 pt-2">
              <label className="flex items-center gap-2 p-2 bg-slate-950/40 border border-slate-800/60 rounded-xl cursor-pointer hover:bg-slate-950/85 transition-colors">
                <input
                  type="checkbox"
                  checked={includeUpper}
                  onChange={(e) => setIncludeUpper(e.target.checked)}
                  className="rounded border-slate-800 text-emerald-500 focus:ring-emerald-500/30 bg-slate-950 w-3.5 h-3.5 accent-emerald-500"
                />
                <span className="text-[10px] font-semibold text-slate-300">A-Z Uppercase</span>
              </label>

              <label className="flex items-center gap-2 p-2 bg-slate-950/40 border border-slate-800/60 rounded-xl cursor-pointer hover:bg-slate-950/85 transition-colors">
                <input
                  type="checkbox"
                  checked={includeLower}
                  onChange={(e) => setIncludeLower(e.target.checked)}
                  className="rounded border-slate-800 text-emerald-500 focus:ring-emerald-500/30 bg-slate-950 w-3.5 h-3.5 accent-emerald-500"
                />
                <span className="text-[10px] font-semibold text-slate-300">a-z Lowercase</span>
              </label>

              <label className="flex items-center gap-2 p-2 bg-slate-950/40 border border-slate-800/60 rounded-xl cursor-pointer hover:bg-slate-950/85 transition-colors">
                <input
                  type="checkbox"
                  checked={includeNumbers}
                  onChange={(e) => setIncludeNumbers(e.target.checked)}
                  className="rounded border-slate-800 text-emerald-500 focus:ring-emerald-500/30 bg-slate-950 w-3.5 h-3.5 accent-emerald-500"
                />
                <span className="text-[10px] font-semibold text-slate-300">0-9 Numeric</span>
              </label>

              <label className="flex items-center gap-2 p-2 bg-slate-950/40 border border-slate-800/60 rounded-xl cursor-pointer hover:bg-slate-950/85 transition-colors">
                <input
                  type="checkbox"
                  checked={includeSymbols}
                  onChange={(e) => setIncludeSymbols(e.target.checked)}
                  className="rounded border-slate-800 text-emerald-500 focus:ring-emerald-500/30 bg-slate-950 w-3.5 h-3.5 accent-emerald-500"
                />
                <span className="text-[10px] font-semibold text-slate-300">!@# Special</span>
              </label>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="phrase"
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            transition={{ duration: 0.15 }}
            className="space-y-3.5 text-left"
          >
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-semibold text-slate-400">Words Number: <span className="text-emerald-400 font-bold">{phraseLength}</span> words</span>
              </div>
              <input
                type="range"
                min="3"
                max="8"
                value={phraseLength}
                onChange={(e) => setPhraseLength(parseInt(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer bg-slate-800 h-1 rounded-lg appearance-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5 pt-2">
              <div>
                <span className="text-[10px] font-semibold text-slate-400 block mb-1">Separator:</span>
                <select
                  value={phraseSeparator}
                  onChange={(e) => setPhraseSeparator(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-300 rounded-lg p-1.5 text-[10px] focus:outline-none focus:ring-1 focus:ring-emerald-500/40 font-mono"
                >
                  <option value="-">Hyphen ( - )</option>
                  <option value="_">Underline ( _ )</option>
                  <option value=".">Dot ( . )</option>
                  <option value=" ">Space (   )</option>
                </select>
              </div>

              <div className="flex flex-col justify-end">
                <label className="flex items-center gap-2 p-1.5 bg-slate-950/40 border border-slate-800/60 rounded-xl cursor-pointer hover:bg-slate-950/85 transition-colors h-full">
                  <input
                    type="checkbox"
                    checked={phraseNumbers}
                    onChange={(e) => setPhraseNumbers(e.target.checked)}
                    className="rounded border-slate-800 text-emerald-500 focus:ring-emerald-500/30 bg-slate-950 w-3.5 h-3.5 accent-emerald-500"
                  />
                  <span className="text-[10px] font-semibold text-slate-300">Append Number</span>
                </label>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {onUsePassword && (
        <button
          onClick={() => onUsePassword(generatedPassword)}
          className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-2.5 rounded-xl mt-4 transition-all shadow-md hover:shadow-emerald-500/10 active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer"
        >
          Use Generated Password
        </button>
      )}
    </div>
  );
}
