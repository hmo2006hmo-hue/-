import { useState, useEffect, FormEvent } from "react";
import { encryptText, decryptText } from "../utils/crypto";
import { ShieldCheck, ShieldAlert, KeyRound, Eye, EyeOff, Lock, RefreshCw } from "lucide-react";
import { motion } from "motion/react";

interface MasterPasswordScreenProps {
  onUnlock: (password: string) => void;
}

export default function MasterPasswordScreen({ onUnlock }: MasterPasswordScreenProps) {
  const [isFirstTime, setIsFirstTime] = useState(false);
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const isConfigured = localStorage.getItem("vault_initialized");
    if (!isConfigured) {
      setIsFirstTime(true);
    }
  }, []);

  const handleInitialize = async (e: FormEvent) => {
    e.preventDefault();
    setError("");

    if (!password) {
      setError("Please specify a strong master password.");
      return;
    }

    if (password.length < 8) {
      setError("Master password must be at least 8 characters long.");
      return;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match. Please try again.");
      return;
    }

    setLoading(true);
    try {
      const verificationToken = "VAULT_LOCK_SUCCESS";
      const encrypted = await encryptText(verificationToken, password);
      localStorage.setItem("vault_verification", encrypted);
      localStorage.setItem("vault_initialized", "true");
      onUnlock(password);
    } catch (err) {
      setError("Local crypto environments encountered an integration error.");
    } finally {
      setLoading(false);
    }
  };

  const handleUnlock = async (e: FormEvent) => {
    e.preventDefault();
    setError("");

    if (!password) {
      setError("Please key in your master password to unlock.");
      return;
    }

    setLoading(true);
    try {
      const storedVerification = localStorage.getItem("vault_verification");
      if (!storedVerification) {
        setError("Local vault keys have been corrupted or cleared. Reinitialize.");
        setLoading(false);
        return;
      }

      const decrypted = await decryptText(storedVerification, password);
      if (decrypted === "VAULT_LOCK_SUCCESS") {
        onUnlock(password);
      } else {
        setError("Incorrect master password. Please verify and retry.");
      }
    } catch (err) {
      setError("Decryption failed. Invalid master password credentials.");
    } finally {
      setLoading(false);
    }
  };

  const toggleShowPassword = () => setShowPassword(!showPassword);

  return (
    <div id="master-auth-container" className="min-h-screen flex items-center justify-center bg-slate-950 font-sans p-4 relative overflow-hidden">
      {/* Visual background details in Slate Emerald Theme */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-emerald-950/15 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-slate-900/40 rounded-full blur-[120px] pointer-events-none w-full" />
      <div className="absolute inset-0 bg-[radial-gradient(#0f172a_1px,transparent_1px)] [background-size:16px_16px] opacity-20" />

      <motion.div 
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
        className="w-full max-w-md bg-slate-900/80 border border-slate-800/60 rounded-2xl shadow-2xl shadow-slate-950 p-8 backdrop-blur-xl relative z-10"
      >
        <div className="flex flex-col items-center text-center mb-6">
          <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl mb-4 relative">
            <ShieldCheck className="w-10 h-10 text-emerald-400" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-slate-900 animate-ping" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-slate-900" />
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            Slate Secure Vault
          </h1>
          <p className="text-xs text-slate-400 mt-2">
            {isFirstTime 
              ? "Establish your device-encrypted zero-knowledge key store" 
              : "Zero-knowledge military grade password container"
            }
          </p>
        </div>

        {isFirstTime ? (
          <form onSubmit={handleInitialize} className="space-y-4 text-left">
            <div className="bg-emerald-950/35 border border-emerald-500/20 rounded-xl p-3.5 text-xs text-emerald-300 leading-relaxed">
              🔑 <strong className="text-emerald-400">Security Architecture:</strong> Your master password derives a 256-bit AES cryptographic key locally via PBKDF2. No passwords or plain entries ever touch any remote server. Since we maintain absolute zero-knowledge, <strong className="text-emerald-200">losing this password permanently compromises access to your vault.</strong>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-400 block ml-1">Setup Master Password</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 8 strong characters"
                  className="w-full bg-slate-950 border border-slate-800/80 rounded-xl py-2.5 px-4 pr-10 text-slate-200 text-sm focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/20 transition-all font-mono placeholder:text-slate-600"
                />
                <button
                  type="button"
                  onClick={toggleShowPassword}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="space-y-1.5 font-mono">
              <label className="text-xs font-semibold text-slate-400 block ml-1 font-sans">Retype Master Password</label>
              <input
                type={showPassword ? "text" : "password"}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm password"
                className="w-full bg-slate-950 border border-slate-800/80 rounded-xl py-2.5 px-4 text-slate-200 text-sm focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/20 transition-all placeholder:text-slate-600"
              />
            </div>

            {error && (
              <div className="flex items-center gap-2.5 p-3 bg-red-950/40 border border-red-900/20 rounded-xl text-xs text-red-400">
                <ShieldAlert className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-3 rounded-xl transition-all shadow-lg hover:shadow-emerald-500/15 flex items-center justify-center gap-2 active:scale-[0.99] cursor-pointer"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4.5 h-4.5 animate-spin" />
                  Generating Local Credentials Store...
                </>
              ) : (
                "Initialize Secure Vault & Begin"
              )}
            </button>
          </form>
        ) : (
          <form onSubmit={handleUnlock} className="space-y-4 text-left">
            <div className="space-y-1.5">
              <div className="flex justify-between items-center px-1">
                <label className="text-xs font-semibold text-slate-300">Enter Vault Master Password</label>
                <div className="flex items-center gap-1 text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 uppercase">
                  <Lock className="w-2.5 h-2.5" /> Secured
                </div>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter master password to derive cryptographic key"
                  className="w-full bg-slate-950 border border-slate-800/80 rounded-xl py-2.5 px-4 pr-10 text-slate-200 text-sm focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/20 transition-all font-mono placeholder:text-slate-600"
                />
                <button
                  type="button"
                  onClick={toggleShowPassword}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2.5 p-3 bg-red-950/40 border border-red-900/20 rounded-xl text-xs text-red-400">
                <ShieldAlert className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-3 rounded-xl transition-all shadow-lg hover:shadow-emerald-500/20 flex items-center justify-center gap-2 active:scale-[0.99] cursor-pointer"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Deriving Cryptographic Keys...
                </>
              ) : (
                <>
                  <KeyRound className="w-4 h-4" />
                  Unlock Encrypted Vault
                </>
              )}
            </button>

            <div className="text-center pt-3 border-t border-slate-800/40 mt-4">
              <button
                type="button"
                onClick={() => {
                  if (confirm("🚨 Emergency Reset Warning! This operation will permanently wipe all local encrypted passwords from this device's memory. This is non-reversible. Do you wish to continue?")) {
                    localStorage.clear();
                    setIsFirstTime(true);
                    setPassword("");
                    setConfirmPassword("");
                    setError("");
                  }
                }}
                className="text-[10px] text-red-500 hover:text-red-400 hover:underline transition-colors"
                id="emergency-reset-trigger"
              >
                Emergency Factory Reset & Wipe Data
              </button>
            </div>
          </form>
        )}
      </motion.div>
    </div>
  );
}
