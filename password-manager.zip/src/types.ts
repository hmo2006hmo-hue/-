export interface VaultItem {
  id: string;
  title: string;
  emailOrUsername: string;
  password?: string; // Cache plain password temporarily when unlocked if needed
  encryptedPassword: string; // Stored AES-encrypted in localStorage
  category: "social" | "personal" | "work" | "financial" | "shopping" | "other";
  notes: string;
  tags: string[];
  createdAt: string; // Exact ISO timestamp or formatted locale string
  lastModifiedAt: string; // Exact ISO timestamp of last edit
  strength: "weak" | "moderate" | "strong";
  score: number; // 0 to 100
  website?: string;
}

export type CategoryType = "all" | "social" | "personal" | "work" | "financial" | "shopping" | "other";

export interface VaultStats {
  total: number;
  weakCount: number;
  moderateCount: number;
  strongCount: number;
  reusedCount: number;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}

export interface AutofillConfig {
  accessibilityActive: boolean;
  autofillServiceActive: boolean;
  overlayStyle: "emerald-pill" | "keyboard-dock" | "clipboard-inject";
  clipboardAutoClearSec: number;
}
