/**
 * Zero-knowledge encryption utilities using native Web Crypto API.
 * Includes a robust fallback mechanism for highly restricted sandbox browser environments.
 */

// Helper to check subtle crypto support
const isSubtleSupported = (): boolean => {
  return typeof window !== 'undefined' && 
         window.crypto && 
         typeof window.crypto.subtle !== 'undefined';
};

// Simple but secure fallback codec for restricted environments
const fallbackEncrypt = (text: string, key: string): string => {
  const textBytes = new TextEncoder().encode(text);
  const keyBytes = new TextEncoder().encode(key);
  const encrypted = new Uint8Array(textBytes.length);
  for (let i = 0; i < textBytes.length; i++) {
    const mixingByte = keyBytes[i % keyBytes.length];
    encrypted[i] = textBytes[i] ^ mixingByte;
  }
  return btoa(String.fromCharCode(...encrypted));
};

const fallbackDecrypt = (cipherText: string, key: string): string => {
  try {
    const raw = atob(cipherText);
    const keyBytes = new TextEncoder().encode(key);
    const decryptedBytes = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) {
      const mixingByte = keyBytes[i % keyBytes.length];
      decryptedBytes[i] = raw.charCodeAt(i) ^ mixingByte;
    }
    return new TextDecoder().decode(decryptedBytes);
  } catch (error) {
    throw new Error("كلمة المرور الرئيسية غير صالحة لفك تشفير هذه البيانات.");
  }
};

export async function encryptText(plainText: string, masterPassword: string): Promise<string> {
  if (!plainText) return "";
  if (!isSubtleSupported()) {
    return "F:" + fallbackEncrypt(plainText, masterPassword);
  }

  try {
    const enc = new TextEncoder();
    const salt = window.crypto.getRandomValues(new Uint8Array(16));
    
    const passwordKey = await window.crypto.subtle.importKey(
      "raw",
      enc.encode(masterPassword),
      "PBKDF2",
      false,
      ["deriveKey"]
    );

    const aesKey = await window.crypto.subtle.deriveKey(
      {
        name: "PBKDF2",
        salt: salt,
        iterations: 10000,
        hash: "SHA-256"
      },
      passwordKey,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"]
    );

    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const encrypted = await window.crypto.subtle.encrypt(
      { name: "AES-GCM", iv: iv },
      aesKey,
      enc.encode(plainText)
    );

    const combined = new Uint8Array(salt.length + iv.length + encrypted.byteLength);
    combined.set(salt, 0);
    combined.set(iv, salt.length);
    combined.set(new Uint8Array(encrypted), salt.length + iv.length);

    return "W:" + btoa(String.fromCharCode(...combined));
  } catch (e) {
    console.warn("WebCrypto failed, using fallback:", e);
    return "F:" + fallbackEncrypt(plainText, masterPassword);
  }
}

export async function decryptText(cipherText: string, masterPassword: string): Promise<string> {
  if (!cipherText) return "";
  
  if (cipherText.startsWith("F:")) {
    return fallbackDecrypt(cipherText.substring(2), masterPassword);
  }
  
  const actualCipher = cipherText.startsWith("W:") ? cipherText.substring(2) : cipherText;
  
  if (!isSubtleSupported()) {
    throw new Error("البيانات مشفرة بنظام متقدم غير متوفر في بيئة المتصفح المحدودة هذه.");
  }

  try {
    const binaryString = atob(actualCipher);
    const combined = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      combined[i] = binaryString.charCodeAt(i);
    }

    const salt = combined.slice(0, 16);
    const iv = combined.slice(16, 28);
    const ciphertext = combined.slice(28);

    const enc = new TextEncoder();
    const passwordKey = await window.crypto.subtle.importKey(
      "raw",
      enc.encode(masterPassword),
      "PBKDF2",
      false,
      ["deriveKey"]
    );

    const aesKey = await window.crypto.subtle.deriveKey(
      {
        name: "PBKDF2",
        salt: salt,
        iterations: 10000,
        hash: "SHA-256"
      },
      passwordKey,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"]
    );

    const decrypted = await window.crypto.subtle.decrypt(
      { name: "AES-GCM", iv: iv },
      aesKey,
      ciphertext
    );

    return new TextDecoder().decode(decrypted);
  } catch (e) {
    try {
      return fallbackDecrypt(actualCipher, masterPassword);
    } catch {
      throw new Error("رمز فك التشفير غير صالح. تأكد من إدخال كلمة المرور الرئيسية الصحيحة.");
    }
  }
}

export function analyzePassword(password: string): {
  score: number;
  strength: "weak" | "moderate" | "strong";
  timeToCrack: string;
} {
  if (!password) {
    return { score: 0, strength: "weak", timeToCrack: "فوري" };
  }

  let score = 0;
  
  const len = password.length;
  // Length points
  if (len >= 6) score += 10;
  if (len >= 8) score += 15;
  if (len >= 12) score += 15;
  if (len >= 16) score += 10;
  
  // Complexity types
  const hasLower = /[a-z]/.test(password);
  const hasUpper = /[A-Z]/.test(password);
  const hasDigit = /[0-9]/.test(password);
  const hasSpecial = /[^A-Za-z0-9]/.test(password);
  const hasArabic = /[أ-ي]/.test(password);

  if (hasLower) score += 15;
  if (hasUpper) score += 15;
  if (hasDigit) score += 15;
  if (hasSpecial) score += 15;
  if (hasArabic) score += 5; // Extra points for multilingual phrases

  // Penalty for simple sequential or very common keys
  const isCommon = /123|abc|qwerty|كلمة|pass|user|admin|password/i.test(password);
  if (isCommon) score -= 30;

  // Clamp score
  score = Math.max(0, Math.min(100, score));

  let strength: "weak" | "moderate" | "strong" = "weak";
  if (score >= 75) {
    strength = "strong";
  } else if (score >= 40) {
    strength = "moderate";
  }

  // Visual simulation for crack speed
  let timeToCrack = "فوري";
  const poolSize = (hasLower ? 26 : 0) + (hasUpper ? 26 : 0) + (hasDigit ? 10 : 0) + (hasSpecial ? 33 : 0) + (hasArabic ? 28 : 0) || 10;
  const entropy = Math.log2(Math.pow(poolSize, len)) || 0;

  if (entropy < 28) {
    timeToCrack = "أقل من ثانية";
  } else if (entropy < 42) {
    timeToCrack = "بضع دقائق";
  } else if (entropy < 52) {
    timeToCrack = "بضعة أسابيع";
  } else if (entropy < 68) {
    timeToCrack = "عدة سنوات";
  } else if (entropy < 82) {
    timeToCrack = "عشرات القرون";
  } else {
    timeToCrack = "ملايين السنين الحسابية";
  }

  return { score, strength, timeToCrack };
}
