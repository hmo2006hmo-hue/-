import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API endpoint for AI Security Advisor (الخبير الأمني لخطوط الحماية)
  app.post("/api/security-assistant", async (req, res) => {
    try {
      const { message, chatHistory } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ 
          error: "مفتاح API للذكاء الاصطناعي (Gemini) غير مهيأ بعد. يرجى تهيئته في لوحة الإعدادات لاستخدام ميزات المساعد الذكي." 
        });
      }

      const ai = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      // Format previous chat messages for Gemini
      const formattedHistory = (chatHistory || []).map((msg: any) => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: msg.content }]
      }));

      // Expert system instruction to ensure professional and highly secure Cyber-Security Consultation in Arabic
      const systemInstruction = 
        "أنت خبير محترف ومستشار أمن سيبراني متميز يدعى 'درع الأمان الذكي'." +
        "مهمتك الأساسية هي تقديم المشورة الأمنية والإرشادات لحفظ وتأمين الحسابات باللغة العربية الفصحى المبسطة والمهنية." +
        "تنبيه أمان قاطع: إذا قام المستخدم بإدخال أو مشاركة كلمة سر فعلية، قم بتنبيهه وتحذيره فوراً وبشكل حازم وودي بأن لا يشارك أبداً أي كلمة مرور حقيقية مع نماذج الذكاء الاصطناعي أو أي منصة عامة لحماية أمنه الشخصي! انصحه بتحليل هيكلية كلمات السر افتراضياً دون كتابتها." +
        "قدم نصائح ملهمة وعملية حول:" +
        "1. كيفية إنشاء عبارات مرور قوية وسهلة التذكر (مثلاً دمج 3 كلمات عربية غير مترابطة مع رموز وأرقام)." +
        "2. أهمية واستخدام المصادقة الثنائية (MFA / 2FA) والتحقق بخطوتين." +
        "3. كيفية التحقق مما إذا كانت حساباته قد تعرضت للتسريب في تسريبات البيانات الشهيرة." +
        "4. توعية هامة حول هجمات التصيد الإلكتروني (Phishing) وكيفية تمييز روابط تسجيل الدخول المزيفة." +
        "أجب باختصار منسق ومقروء بوضوح واستخدم نقاط واضحة وعلامات مميزة لجعل القراءة مريحة.";

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: [
          ...formattedHistory,
          { role: 'user', parts: [{ text: message }] }
        ],
        config: {
          systemInstruction: systemInstruction,
          temperature: 0.7,
        }
      });

      res.json({ reply: response.text });
    } catch (error: any) {
      console.error("Gemini API Error in backend:", error);
      res.status(500).json({ 
        error: "فشل في التواصل مع خوادم الذكاء الاصطناعي. يرجى مراجعة إعدادات الاتصال وحالة الاتصال بالإنترنت." 
      });
    }
  });

  // Integrating Vite Dev server or Production builds
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Password Manager full-stack server running on http://localhost:${PORT}`);
  });
}

startServer();
